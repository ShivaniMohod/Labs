// $scope.mulImage=[];
//    $scope.mulImage.push({'image':null,'filename':''});
//    console.log('mulimage',$scope.mulImage);
//    $scope.addNewImageRow=function(mulImage){
//        console.log('total image',mulImage.length);
//        mulImage.push({'image':null,'filename':''});
//        console.log('end total image',mulImage.length);

//    }
//    $scope.deleteNewImageRow=function(mulImage,index){
//        mulImage.splice(index,1);
//        console.log('file',$scope.mulImage);
//    }
//    $scope.onFileSelect1 = function(index) {
//          $scope.mulImage[index]['filename']='';

//    }