package com.cg.step;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Login;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefination2 {

	private WebDriver driver;
	private Login login;

	@Before
	public void init() {
		// Instantiate Driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@After
	public void destroy() {
		driver.quit();
	}
	
	@When("^User selects type$")
	public void user_selects_type() throws Throwable {
		login.selectUser(1);
	}

	@Then("^Validate user type$")
	public void validate_user_type() throws Throwable {
		login.clickLogin();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		String url = "file:///C:\\Users\\smohod\\Desktop\\Module 3\\Spring Labs\\HelloBDDProject\\HTML\\login.html";
		driver.get(url);
		login = new Login();
		PageFactory.initElements(driver,  login);
	}

	@When("^User enters username$")
	public void user_enters_username() throws Throwable {
//		WebElement uname = driver.findElement(By.id("username"));
		login.selectUser(0);
		login.setUsername("abc");
	}

	@Then("^Validate username$")
	public void validate_username() throws Throwable {
//		WebElement login = driver.findElement(By.id("login"));
//		login.submit();
//		Thread.sleep(2000);
//		driver.switchTo().alert().accept();
//		Thread.sleep(2000);
		login.clickLogin();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters password$")
	public void user_enters_password() throws Throwable {
//		WebElement uname = driver.findElement(By.id("username"));
//		uname.sendKeys("qwer");
//		WebElement pwd = driver.findElement(By.id("password"));
//		pwd.sendKeys("ora");
		login.selectUser(0);
		login.setUsername("abcd");
		login.setPassword("123");
	}

	@Then("^Validate password$")
	public void validate_password() throws Throwable {
//		WebElement login = driver.findElement(By.id("login"));
//		login.submit();
//		Thread.sleep(2000);
//		driver.switchTo().alert().accept();
//		Thread.sleep(2000);
		login.clickLogin();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User selects role$")
	public void user_selects_role() throws Throwable {
		login.selectUser(0);
		login.setUsername("abcd");
		login.setPassword("qwer");
		login.selectRole(0);
	}

	@Then("^Validate role$")
	public void validate_role() throws Throwable {
		login.clickLogin();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}
	
	@When("^User selects remember me$")
	public void user_selects_remember_me() throws Throwable {
		login.selectUser(0);
		login.setUsername("abcd");
		login.setPassword("qwer");
		login.selectRole(0);
		login.clickRemember();
	}

	@Then("^Validate check box$")
	public void validate_check_box() throws Throwable {
		login.clickLogin();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}
	
	@When("^User submit form$")
	public void user_submit_form() throws Throwable {
//		WebElement uname = driver.findElement(By.id("username"));
//		uname.sendKeys("qwer");
//		WebElement pwd = driver.findElement(By.id("password"));
//		pwd.sendKeys("orac");
		login.selectUser(0);
		login.setUsername("abcd");
		login.setPassword("1234");
		login.selectRole(2);
	}

	@Then("^Show successful alert$")
	public void show_successful_alert() throws Throwable {
//		WebElement login = driver.findElement(By.id("login"));
//		login.submit();
//		Thread.sleep(2000);
//		driver.switchTo().alert().accept();
//		Thread.sleep(2000);
		login.clickLogin();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}
}
