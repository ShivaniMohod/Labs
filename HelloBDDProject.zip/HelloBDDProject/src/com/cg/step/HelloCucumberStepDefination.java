package com.cg.step;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HelloCucumberStepDefination {
	
	@Before
	public void init() {
		System.out.println("This will execute before each step");
	}
	
	@After
	public void Destroy() {
		System.out.println("Scenario test ends\n");
	}
	
	@Given("^Attended Training$")
	public void attended_Training() throws Throwable {
		System.out.println("1-Attended training");
	}

	@When("^Clear L(\\d+)$")
	public void clear_L(int arg1) throws Throwable {
		System.out.println("2-Cleared L1");
	}

	@Then("^Become Employee$")
	public void become_Employee() throws Throwable {
		System.out.println("3-I'm a slave");
	}
	
	@Given("Hello given step$")
	public void Hello_Given_Step() throws Throwable {
		System.out.println("Saying Hello to Given step");
	}
	
	@When("Hello when step$")
	public void Hello_When_Step() throws Throwable {
		System.out.println("Saying Hello to When step");
	}
	
	@Then("Hello then step$")
	public void Hello_Then_Step() throws Throwable {
		System.out.println("Saying Hello to Then step");
	}
	
	@Given("Bye given step$")
	public void Bye_Given_Step() throws Throwable {
		System.out.println("Saying Bye to Given step");
	}
	
	@When("Bye when step$")
	public void Bye_When_Step() throws Throwable {
		System.out.println("Saying Bye to When step");
	}
	
	@Then("Bye then step$")
	public void Bye_Then_Step() throws Throwable {
		System.out.println("Saying Bye to Then step");
	}
}
