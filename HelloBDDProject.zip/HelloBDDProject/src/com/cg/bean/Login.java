package com.cg.bean;

import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Login {

	@FindBy(id = "user")
	private List<WebElement> user;
	
	@FindBy(id = "username")
	private WebElement username;

	@FindBy(id = "password")
	private WebElement password;

	@FindBy(id = "role")
	private WebElement role;
	
	@FindBy(id="remember")
	private WebElement remember;

	@FindBy(id = "login")
	private WebElement login;

	public void selectUser(int idx) {
		this.user.get(idx).click();
	}

	public String getUsername() {
		return username.getAttribute("value");
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public void selectRole(int idx) {
		Select select = new Select(role);
		select.selectByIndex(idx);
	}
	
	public void clickRemember() {
		remember.click();
	}

	public String getLogin() {
		return login.getAttribute("value");
	}

	public void setLogin(String login) {
		this.login.sendKeys(login);
	}

	public void clickLogin() {
		login.click();
	}
	
}
