package com.cg.project.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class ConferenceRegistration {

	@FindBy(id="txtFirstName")
	WebElement firstName;
	
	@FindBy(id="txtLastName")
	WebElement lastName;
	
	@FindBy(id="txtEmail")
	WebElement email;
	
	@FindBy(id="txtPhone")
	WebElement phoneNumber;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[5]/td[2]/select")
	WebElement peopleCount;
	
	@FindBy(id="txtAddress1")
	WebElement address;
	
	@FindBy(id="txtAddress2")
	WebElement area;
	
	@FindBy(name="city")
	WebElement city;

	@FindBy(name="state")
	WebElement state;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[12]/td[2]/input")
	WebElement memberType;
	
	@FindBy(tagName="a")
	WebElement nextButton;
	
	public ConferenceRegistration() {}

	public String getFirstName() {
		return this.firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return this.lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return this.email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getPhoneNumber() {
		return this.phoneNumber.getAttribute("value");
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber.sendKeys(phoneNumber);
	}

	public String getAddress() {
		return this.address.getAttribute("value");
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public String getArea() {
		return this.area.getAttribute("value");
	}

	public void setArea(String area) {
		this.area.sendKeys(area);
	}
	
	public void clickPeople() {
		Select select = new Select(peopleCount);
		select.selectByIndex(2);
	}
	
	public void clickCity() {
		Select select = new Select(city);
		select.selectByVisibleText("Pune");
	}
	
	public void clickState() {
		Select select = new Select(state);
		select.selectByVisibleText("Maharashtra");
	}
	
	public void clickMemberStatus() {
		memberType.click();
	}
	
	public void clickNextButton() {
		nextButton.click();
	}
}